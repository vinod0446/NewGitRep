java -jar /myproject-0.0.1-SNAPSHOT.jar
