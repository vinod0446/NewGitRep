# A Hello World Spring Boot App

A Hello World Spring Boot app.
